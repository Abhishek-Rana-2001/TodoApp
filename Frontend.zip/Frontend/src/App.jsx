import { useState } from 'react'
import {BrowserRouter, Route, Routes}  from "react-router-dom"
import './App.css'
import Home from './pages/Home'
import Menu from './pages/Menu'
import Reservation from './pages/Reservation'
import Sidebar from './components/Sidebar'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Clock from './components/clock/Clock'

function App() {
  const [count, setCount] = useState(0)

  const isLoggedIn = localStorage.getItem("isLoggedIn")

  return (
    <div className='flex justify-center items-center w-screen bg-[#222] overflow-hidden' style={{height : "100dvh"}}>
    <BrowserRouter>
    {isLoggedIn ? <Sidebar/> : <></>}
    <div className='w-full p-10 border-1 border-red rounded-md'>
    <Routes>
      <Route path='/' element={<Login/>}/>
      <Route path='/dashboard' element={<Dashboard/>}/>
      <Route path='/register' element={<Register/>}/>
      <Route path='/menu' element={<Menu/>}/>
      <Route path='/reservation' element={<Reservation/>}/>
    </Routes>
    </div>
    </BrowserRouter>
    {/* <div className='w-3/4 h-full'>

    </div>
    <div className=' w-80 h-80 flex justify-center items-center'>
    <Clock/>
    </div> */}
    </div>
  )
}

export default App
