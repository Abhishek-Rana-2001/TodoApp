import React from 'react'

export default function Dashboard() {
  return (
    <div className=' h-full text-white'>
      Dashboard
      
    </div>
  )
}
