import React from 'react'

export default function Reservation() {
  return (
    <div>
      Reservation
    </div>
  )
}
