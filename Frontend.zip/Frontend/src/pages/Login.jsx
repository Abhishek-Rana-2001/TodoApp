import axios from "axios";
import React, { useState  } from "react";
import { NavLink ,  useNavigate} from "react-router-dom";

export default function Login() {
  const navigate = useNavigate()
 
  const [loginInfo , setLogininfo] = useState({
    email : "",
    password : ""
  })

  const handleInputs = (field)=>(e)=>{
     setLogininfo(prev=>({...prev , [field] : e.target.value}))
  }

  const handleSubmit = async(e)=>{
    e.preventDefault()
    await axios.post("http://localhost:8080/api/login" , loginInfo )
    .then(res=>{
      if(res.data.status === "ok"){
        localStorage.setItem('isLoggedIn' , true)
        navigate("/dashboard")
      }
    })
  }

  return (
   <div className="w-full h-full flex justify-center items-center">
      <div className="w-1/4 h-2/3 bg-transparent backdrop-blur-md rounded-lg">
        <form className="h-full w-full flex flex-col gap-3 justify-center items-center p-3" onSubmit={handleSubmit}>
          <label className="text-4xl font-bold">Login</label>
          <input placeholder="email" className="p-2 w-full rounded-lg focus:outline-blue-300 " onChange={handleInputs("email")}></input>
          <input placeholder="password" className="p-2 w-full rounded-lg focus:outline-blue-300 " onChange={handleInputs("password")}></input>
          <button className="p-2 bg-rose-500 text-white rounded-lg">Submit</button>
        </form>

      </div>
   </div>
  );
}
