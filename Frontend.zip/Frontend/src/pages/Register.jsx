import React, { useState } from 'react'
import axios from "axios"
import { NavLink, useNavigate } from 'react-router-dom'

export default function Register() {

    const navigate = useNavigate()

    const [userData , setUserData] = useState({
        name : "",
        email: "",
        password : ""
    })

    const handleInputs = (input)=>(e)=>{
        setUserData(prev=>({...prev , [input] : e.target.value}))
    }


    const handleSubmit = async(e)=>{
        e.preventDefault()
        await axios.post("http://localhost:8080/api/register" , userData )
        .then(res=>console.log(res))
    }

  return (
    <div className="w-full h-full flex justify-center items-center ">
      <div style={{width : "25rem" , height : "35rem"}} className=" rounded-md shadow-md flex bg-white flex-col items-center gap-2 justify-center ">
        <div className='flex flex-col items-center gap-20 justify-center'>

        <h1 className=" text-6xl font-bold">Register</h1>
        
        <form className="flex flex-col gap-4 text-xl" onSubmit={handleSubmit}>  
          

        <input style={{border : "1px solid black"}} type="text" className="border-slate-400 border-1 rounded-md p-2" placeholder="Name" value={userData.name} onChange={handleInputs("name")} />
        <input style={{border : "1px solid black"}} type="email" className="border-slate-400 border-1 rounded-md p-2" placeholder="Email" value={userData.email} onChange={handleInputs("email")} />

          <input style={{border : "1px solid black"}} type="password" className="border-slate-400 border-1 rounded-md p-2" placeholder="password" value={userData.password} onChange={handleInputs("password")} />
          

          <div className="flex justify-end text-sm">
            <label>Forgot Password? <a className="hover:cursor-pointer text-blue-400 ">Click Here</a></label>
          </div>

          <button type="submit" className=" border-1 border-slate-500 bg-slate-400 p-2 rounded-md">Submit</button>
        </form>
        </div>
          <div className="flex flex-col gap-2 ">

          <label className="text-sm text-center">Already have an account?</label>
          <button className=" border-1 border-slate-500 bg-slate-400 p-2 rounded-md text-md " onClick={()=>navigate("/")}>Login</button>
          </div>
      </div>
    </div>
  )
}
