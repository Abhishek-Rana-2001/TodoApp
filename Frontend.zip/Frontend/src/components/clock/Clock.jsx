import React, { useEffect, useState } from 'react'
import "./clock.css"

export default function Clock() {
    const [time, setTime] = useState(new Date());

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

  const hours = time.getHours() % 12;
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();

  const hourRotation = `rotate(${(hours + minutes / 60) * 30}deg)`;
  const minuteRotation = `rotate(${minutes * 6}deg)`;
  const secondRotation = `rotate(${seconds * 6}deg)`;

    const numbers = Array.from({ length: 12 }, (_, index) => index + 1);
  return (
    <div className='container'>
        <div className='clock text-yellow-400'>
        <div style={{ '--clr': "#ff3d58",  transform: hourRotation, "--h" : "60px"}}  className={`hand`} ><i></i></div>
          <div style={{ '--clr': "#00a6ff",  transform:minuteRotation, "--h" : "80px"}} className={`hand`} ><i></i></div>
          <div style={{ '--clr': "#ffffff",  transform: secondRotation, "--h" : "90px"}} className={`hand`} ><i></i></div>
        {numbers.map(number => (
          <span key={number} style={{ '--i': number }}><b>{number}</b></span>
        ))}
        </div>
    </div>
  )
}
