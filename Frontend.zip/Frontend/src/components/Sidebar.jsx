import React, { useState } from "react";
import { NavLink, Navigate, useNavigate } from "react-router-dom";
import { BiMenu } from "react-icons/bi";
import { AiOutlineClose, AiOutlineHome } from "react-icons/ai";
import { TfiMenuAlt } from "react-icons/tfi";
import { BsFillCalendarDateFill } from "react-icons/bs";
import { CiPower } from "react-icons/ci";
import { menuItems } from "../static/dataLists";

export default function Sidebar() {
  const [open, setOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState("Home");

  const navigate = useNavigate()


  const handleLogout = ()=>{
    localStorage.removeItem("isLoggedIn")
    navigate("/")
  }
  return (
    <>
      <div className={`${!open ? "w-72 " : " w-14"} h-screen z-10  bg-white duration-300 ease-in-out`}>
        <button className="p-2" onClick={() => setOpen(!open)}>
          {open ? <BiMenu size={30} /> : <AiOutlineClose size={30} />}
        </button>
        <div className="flex flex-col justify-between">
          <ul>
            {menuItems.map((link) => {
                return (
                  <li
                  key={link.name}
                  className={`p-2 ${
                    activeMenu === link.name ? "bg-black text-white" : ""
                  } hover:bg-black hover:text-white`}
                  onClick={() => setActiveMenu(link.name)}
                  >
                  <NavLink className="flex gap-2 items-center" to={link.link}>
                    {link.icon}
                    <span className={`${open ? "hidden" : ""}`}>{link.name}</span>
                  </NavLink>
                </li>
              );
            })}
          </ul>
          <button className="flex gap-2 items-center p-2" onClick={handleLogout}>
                <CiPower size={30}/>
                <span className={`${open && "hidden"} origin-left duration-200`}>Logout</span>
              </button>
        </div>
      </div>
    </>
  );
}
