export const menuItems = [
    {
      name: "Home",
      link: "/",
      icon: <AiOutlineHome size={30} />,
    },
    {
      name: "Menu",
      link: "/menu",
      icon: <TfiMenuAlt size={30}/>,
    },
    {
      name: "Reservation",
      link: "/reservation",
      icon: <BsFillCalendarDateFill size={30}/>,
    },
  ];